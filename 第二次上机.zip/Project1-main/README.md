Objective: Design a Wikipedia-like online encyclopedia.

Result: [Here](https://www.youtube.com/watch?v=H_t_FEe2C1U&ab_channel=Asgher)
