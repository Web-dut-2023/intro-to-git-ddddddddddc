from django.contrib import admin

# Models registry.
