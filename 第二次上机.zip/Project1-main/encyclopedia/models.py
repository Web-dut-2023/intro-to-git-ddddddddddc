from django.db import models

# Create models.
